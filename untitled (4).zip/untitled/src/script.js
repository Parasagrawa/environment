document.querySelector(".btn").addEventListener("click", function() {
    alert("Thank you for joining the movement! 🌿");
});
